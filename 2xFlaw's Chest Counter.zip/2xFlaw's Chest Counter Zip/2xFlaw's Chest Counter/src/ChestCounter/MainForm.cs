using System.Diagnostics;
using System.Drawing;
using System.Runtime.Versioning;
using System.Windows.Forms;

namespace ChestCounter;

[SupportedOSPlatform("windows")]
public sealed class MainForm : Form
{
    private readonly Monitor monitor;
    private readonly Store store;
    private readonly Dictionary<string, Font> fonts = new();
    private readonly Panel content = new() { Dock=DockStyle.Fill, Padding=new Padding(20), AutoScroll=true };
    private readonly Label total=new(), current=new(), today=new(), average=new(), best=new(), treasures=new(), last=new(), team=new(), notice=new(), profileName=new(), reset=new(), performance=new();
    private readonly ComboBox profiles=new() { DropDownStyle=ComboBoxStyle.DropDownList, Width=210, FlatStyle=FlatStyle.Flat };
    private readonly DailyChart chart=new() { Dock=DockStyle.Fill };
    private readonly Button overlay=new();
    private readonly System.Windows.Forms.Timer clock=new() { Interval=1000 };
    private readonly Image banner, avatar;
    private readonly Dictionary<string,Panel> pages = new();
    private readonly List<Button> navigation = new();
    private string active="Dashboard", profileSignature="", chartSignature="";
    private bool selecting;
    private MonitorState? state;
    private MonitorState? pendingState;
    private int queued;
    private PersonalTools? tools;
    private readonly DataGridView history=new() { Dock=DockStyle.Fill, ReadOnly=true, AllowUserToAddRows=false, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill, RowHeadersVisible=false, BackgroundColor=Theme.Card, BorderStyle=BorderStyle.None, EnableHeadersVisualStyles=false };
    private Font F(float size, FontStyle style=FontStyle.Regular)
    {
        var key=$"{size}:{style}";
        if(!fonts.TryGetValue(key,out var f))fonts[key]=f=new Font("Segoe UI",size,style);
        return f;
    }
    private Label TextLabel(string text,float size=10,Color? colour=null)
        =>new() {Text=text,AutoSize=true,ForeColor=colour??Theme.Ink,Font=F(size),Margin=new Padding(0,0,0,9)};
    private Button ActionButton(string text, Action click)
    {
        var b=new Button {Text=text,AutoSize=true,MinimumSize=new Size(120,38),FlatStyle=FlatStyle.Flat,BackColor=Theme.Panel,ForeColor=Theme.Ink,Font=F(10,FontStyle.Bold),Cursor=Cursors.Hand,Margin=new Padding(0,0,8,8),Padding=new Padding(10,4,10,4)};
        b.FlatAppearance.BorderColor=Theme.CardEdge;b.FlatAppearance.MouseOverBackColor=Theme.PanelHover;b.Click+=(_,_)=>click();return b;
    }
    private Panel Page(string name)
    {
        var p=new Panel {Dock=DockStyle.Fill,BackColor=Theme.Bg,Visible=false,AutoScroll=true};pages[name]=p;content.Controls.Add(p);return p;
    }
    private Panel Metric(string caption,Label number,Color colour)
    {
        var p=new Panel {Dock=DockStyle.Fill,BackColor=Theme.Card,Padding=new Padding(15),Margin=new Padding(6)};
        number.Dock=DockStyle.Fill;number.ForeColor=colour;number.Font=F(27,FontStyle.Bold);number.Text="—";number.TextAlign=ContentAlignment.MiddleLeft;
        var cap=TextLabel(caption.ToUpperInvariant(),9,Theme.Muted);cap.AutoSize=false;cap.Height=24;cap.Dock=DockStyle.Top;
        p.Controls.Add(number);p.Controls.Add(cap);return p;
    }
    private void OpenTools()
    {
        try
        {
            if(tools==null||tools.IsDisposed){tools=new PersonalTools(store,monitor);tools.Show(this);}
            else {if(tools.WindowState==FormWindowState.Minimized)tools.WindowState=FormWindowState.Normal;tools.Activate();}
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"Weekly tools error");}
    }
    public MainForm(Monitor monitor, Store store)
    {
        this.monitor=monitor;this.store=store;
        banner=PersonalBrand.Banner();avatar=PersonalBrand.Avatar();
        Text="2xFlaw's Chest Counter";Size=new Size(1160,850);MinimumSize=new Size(960,720);StartPosition=FormStartPosition.CenterScreen;
        BackColor=Theme.Bg;ForeColor=Theme.Ink;Font=F(10);Icon=AppIcon.Load();AutoScaleMode=AutoScaleMode.Dpi;
        var shell=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=Padding.Empty};shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,200));shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(shell);
        var side=new FlowLayoutPanel {Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,BackColor=Theme.Card,Padding=new Padding(17,25,12,16)};
        shell.Controls.Add(side,0,0);shell.Controls.Add(content,1,0);
        // Removed duplicate sidebar monogram; retain the 2xFlaw name.
        side.Controls.Add(TextLabel("2xFlaw",22,Theme.Accent));side.Controls.Add(TextLabel("CHEST COUNTER",9,Theme.Muted));
        foreach(var n in new[]{"Dashboard","Match history","Weekly chances","Overlay","Settings","Performance"})
        {
            var name=n;var b=ActionButton(n,()=>Navigate(name));b.Width=164;b.Height=44;b.AutoSize=false;navigation.Add(b);side.Controls.Add(b);
        }
        side.Controls.Add(TextLabel("F8  Weekly tools",9,Theme.Muted));
        side.Controls.Add(TextLabel("Personal source build\nOriginal parser retained",8,Theme.Muted));
        BuildDashboard();BuildHistory();BuildPerformance();
        profiles.BackColor=Theme.Panel;profiles.ForeColor=Theme.Ink;profiles.Font=F(10);
        profiles.SelectedIndexChanged+=(_,_)=> {if(!selecting&&profiles.SelectedItem is Profile p)monitor.SetProfile(p.Key);};
        notice.ForeColor=Theme.AccentSoft;notice.Font=F(10);notice.AutoSize=true;notice.MaximumSize=new Size(800,0);
        notice.Click+=(_,_)=>monitor.KeepOpen();
        KeyPreview=true;KeyDown+=(_,e)=> {if(e.KeyCode==Keys.F8){OpenTools();e.Handled=true;}};
        clock.Tick+=(_,_)=>Tick();clock.Start();
        monitor.Changed+=OnChanged;
        Shown+=(_,_)=> {if(monitor.AutoMode)WindowState=FormWindowState.Minimized;};
        Navigate("Dashboard");
    }
    private void BuildDashboard()
    {
        var page=Page("Dashboard");
        var body=new TableLayoutPanel {Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,Padding=Padding.Empty};body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));page.Controls.Add(body);
        body.Controls.Add(new BrandHero(banner,avatar) {Dock=DockStyle.Top,Height=185,Margin=new Padding(0,0,0,14)});
        var heading=new FlowLayoutPanel {Dock=DockStyle.Top,AutoSize=true,WrapContents=true};heading.Controls.Add(TextLabel("Your dashboard",22));heading.Controls.Add(profiles);body.Controls.Add(heading);
        profileName.AutoSize=true;profileName.ForeColor=Theme.Muted;body.Controls.Add(profileName);
        var metrics=new TableLayoutPanel {Dock=DockStyle.Top,Height=255,ColumnCount=3,RowCount=2,Margin=new Padding(0,12,0,12)};
        for(int i=0;i<3;i++)metrics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33.333f));for(int i=0;i<2;i++)metrics.RowStyles.Add(new RowStyle(SizeType.Percent,50));
        metrics.Controls.Add(Metric("Total personal / configured",total,Theme.Accent),0,0);metrics.Controls.Add(Metric("Current / previous match",current,Theme.Ink),1,0);metrics.Controls.Add(Metric("Today",today,Theme.AccentSoft),2,0);
        metrics.Controls.Add(Metric("Average per match",average,Theme.Ink),0,1);metrics.Controls.Add(Metric("Best match",best,Theme.Rose),1,1);metrics.Controls.Add(Metric("Treasures",treasures,Theme.Accent),2,1);body.Controls.Add(metrics);
        var lastPanel=new FlowLayoutPanel {Dock=DockStyle.Top,AutoSize=true,BackColor=Theme.Card,Padding=new Padding(14),FlowDirection=FlowDirection.TopDown,WrapContents=false};
        last.AutoSize=true;last.ForeColor=Theme.Ink;last.Font=F(11,FontStyle.Bold);team.AutoSize=true;team.ForeColor=Theme.Muted;team.MaximumSize=new Size(780,0);lastPanel.Controls.Add(last);lastPanel.Controls.Add(team);body.Controls.Add(lastPanel);
        body.Controls.Add(TextLabel("LAST 7 DAYS",10,Theme.Muted));body.Controls.Add(new Panel {Dock=DockStyle.Top,Height=155,BackColor=Theme.Card,Controls={chart},Margin=new Padding(0,10,0,10)});
        var actions=new FlowLayoutPanel {Dock=DockStyle.Top,AutoSize=true};
        var overlayAction=ActionButton("Toggle game overlay",()=>monitor.ToggleOverlay());
        overlayAction.Name="OverlayAction";actions.Controls.Add(overlayAction);
        actions.Controls.Add(ActionButton("Weekly / import / manual",OpenTools));
        actions.Controls.Add(ActionButton("Open classic report",()=> {try{Process.Start(new ProcessStartInfo(store.ReportPath){UseShellExecute=true});}catch(Exception ex){MessageBox.Show(this,ex.Message);}}));body.Controls.Add(actions);
        reset.AutoSize=true;reset.ForeColor=Theme.Muted;body.Controls.Add(reset);body.Controls.Add(notice);
        body.Controls.Add(TextLabel("Imports are integrated. Manual additions affect totals and daily charts, not match averages. Edit them in Weekly tools.",9,Theme.Muted));
    }
    private void BuildHistory()
    {
        var p=Page("Match history");var bar=new FlowLayoutPanel {Dock=DockStyle.Top,Height=60};bar.Controls.Add(TextLabel("Match history",22));bar.Controls.Add(ActionButton("Refresh",()=>_=LoadHistory()));
        history.DefaultCellStyle.BackColor=Theme.Card;history.DefaultCellStyle.ForeColor=Theme.Ink;history.DefaultCellStyle.SelectionBackColor=Theme.PanelHover;history.DefaultCellStyle.SelectionForeColor=Theme.Ink;
        history.ColumnHeadersDefaultCellStyle.BackColor=Theme.Panel;history.ColumnHeadersDefaultCellStyle.ForeColor=Theme.AccentSoft;history.GridColor=Theme.CardEdge;history.RowTemplate.Height=32;
        p.Controls.Add(history);p.Controls.Add(bar);
    }
    private void BuildPerformance()
    {
        var p=Page("Performance");var col=new FlowLayoutPanel {Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,WrapContents=false,AutoScroll=true};p.Controls.Add(col);
        col.Controls.Add(TextLabel("Performance & behaviour",22));
        performance.AutoSize=true;performance.Font=F(15,FontStyle.Bold);performance.ForeColor=Theme.Accent;col.Controls.Add(performance);
        var info=TextLabel("Native Windows interface — no embedded browser engine.\n\nThe dashboard renders monitor updates; it does not re-read the history on a timer.\nMatch history loads only when you open it or click Refresh (latest 500 matches).\nThe countdown updates only while this window is visible and not minimised.\nImages are resized once and loaded once. Fonts are reused until the window closes.\n\nReplay parsing still uses CPU and RAM; there is no zero-memory or zero-delay guarantee.\nOriginal watcher/parser performance has not been benchmarked or rewritten.\nWeekly tools and its separate overlay retain prototype limitations.\n\nCompare idle, import, and live-match usage in Task Manager before judging performance.",11,Theme.Muted);
        info.MaximumSize=new Size(720,0);col.Controls.Add(info);
    }
    private void Navigate(string name)
    {
        if(name=="Weekly chances"){OpenTools();return;}
        if(name=="Overlay"){monitor.ToggleOverlay();return;}
        if(name=="Settings"){using var f=new SettingsForm(monitor,store);f.ShowDialog(this);return;}
        active=name;foreach(var p in pages){p.Value.Visible=p.Key==name;if(p.Key==name)p.Value.BringToFront();}
        foreach(var b in navigation)b.BackColor=b.Text==name?Theme.PanelHover:Theme.Panel;
        if(name=="Match history")_=LoadHistory();Tick();
    }
    private async Task LoadHistory()
    {
        try
        {
            var c=monitor.Config;
            var rows=await Task.Run(()=>Profiles.View(store.LoadData(),c).Matches.OrderByDescending(m=>m.MatchStartUtc??m.AnalyzedAtUtc).Take(500).Select(m=>new {
                Date=(m.MatchStartUtc??m.AnalyzedAtUtc).ToLocalTime().ToString("dd MMM HH:mm"),
                Mode=m.Playlist??"Unknown",Personal=m.OwnChests,SquadObserved=m.Teammates?.Sum(t=>t.ChestsSeen)??0,
                Treasures=m.TreasureFinds.Count,Place=m.Placement,Eliminations=m.Eliminations
            }).ToList());
            if(!IsDisposed)history.DataSource=rows;
        }catch(Exception ex){if(!IsDisposed)MessageBox.Show(this,ex.Message,"History error");}
    }
    private void OnChanged(MonitorState s)
    {
        pendingState=s;
        if(IsDisposed||!IsHandleCreated||Interlocked.Exchange(ref queued,1)!=0)return;
        try {BeginInvoke(new Action(()=> {Interlocked.Exchange(ref queued,0);if(!IsDisposed&&pendingState is {} latest)Render(latest);}));}
        catch(InvalidOperationException){Interlocked.Exchange(ref queued,0);}
    }
    private static void Set(Label l,string text){if(l.Text!=text)l.Text=text;}
    private void Render(MonitorState s)
    {
        state=s;Set(total,s.View.Total);Set(current,s.View.Current??"—");Set(today,s.Stats.Today.ToString("N0"));
        Set(average,s.Stats.Average.ToString("0.0"));Set(best,s.Stats.BestMatch.ToString("N0"));Set(treasures,s.Stats.Treasures.ToString("N0"));
        Set(profileName,$"{s.Stats.HistoryMatches:N0} saved matches · {L.Culture.TextInfo.ToTitleCase(s.View.CurrentCaption)} · {(monitor.OverlayVisible?"Overlay on":"Overlay off")}");
        Set(last,s.Stats.LastMatch is {} lm?$"Last completed match   {lm.Chests} chests · {lm.Treasures} treasures · {lm.Eliminations?.ToString()??"—"} eliminations":"Waiting for your first completed replay");
        Set(team,s.Team is {} t?$"Observed squad ≥ {t.Total}   |   You {t.Mine}   |   "+string.Join("  ·  ",t.Mates.Select(m=>$"{m.Name} ≥ {m.Chests}")):"Squad data: enable teammate tracking in Settings. Counts are limited to replay visibility.");
        Set(notice,s.Notice??(s.AutoCloseOffer?"Closing with Fortnite — click here to keep open.":""));
        var sig=string.Join("|",s.Profiles.Select(p=>p.Key+":"+p.Name));
        if(sig!=profileSignature){profileSignature=sig;selecting=true;profiles.DisplayMember="Name";profiles.DataSource=s.Profiles.ToList();selecting=false;}
        selecting=true;foreach(var p in profiles.Items.Cast<Profile>())if(p.Key==s.CurrentKey){profiles.SelectedItem=p;break;}selecting=false;
        var daysSignature=string.Join("|",s.Stats.LastDays.Select(d=>$"{d.Day.Ticks}:{d.Chests}"));
        if(daysSignature!=chartSignature){chartSignature=daysSignature;chart.SetDays(s.Stats.LastDays);}
    }
    private void Tick()
    {
        if(!Visible||WindowState==FormWindowState.Minimized)return;
        if(active=="Dashboard")
        {
            var now=DateTime.UtcNow;var end=PersonalTools.Week(now).AddDays(7);var d=end-now;
            Set(reset,$"Weekly reset: {end.ToLocalTime():ddd dd MMM HH:mm} local · {d.Days}d {d.Hours:00}h {d.Minutes:00}m {d.Seconds:00}s");
        }
        if(active=="Performance")
        {
            using var p=Process.GetCurrentProcess();Set(performance,$"Working set: {p.WorkingSet64/1048576.0:0.0} MB   |   Managed heap: {GC.GetTotalMemory(false)/1048576.0:0.0} MB");
        }
    }
    protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);Theme.Chrome(Handle);if(pendingState is {} s)Render(s);}
    protected override void Dispose(bool disposing)
    {
        if(disposing){clock.Stop();clock.Dispose();monitor.Changed-=OnChanged;}
        base.Dispose(disposing);
        if(disposing){banner.Dispose();avatar.Dispose();foreach(var f in fonts.Values)f.Dispose();fonts.Clear();}
    }
}
